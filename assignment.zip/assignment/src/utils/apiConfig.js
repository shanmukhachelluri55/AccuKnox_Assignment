const urls = {
    getDashboardData: '/dashboard.json',
};

export default urls;